pia8255.o pia8255.d: pia8255.cpp pia8255.h \
 /usr/lib/gcc/arm-none-eabi/14.2.1/include/stdint.h \
 /home/lbijn/circle/include/circle/string.h \
 /home/lbijn/circle/include/circle/stdarg.h \
 /home/lbijn/circle/include/circle/types.h \
 /home/lbijn/circle/include/assert.h \
 /home/lbijn/circle/include/circle/macros.h \
 /home/lbijn/circle/include/circle/util.h \
 /home/lbijn/circle/include/circle/logger.h \
 /home/lbijn/circle/include/circle/device.h \
 /home/lbijn/circle/include/circle/ptrlist.h \
 /home/lbijn/circle/include/circle/string.h \
 /home/lbijn/circle/include/circle/timer.h \
 /home/lbijn/circle/include/circle/interrupt.h \
 /home/lbijn/circle/include/circle/bcm2835int.h \
 /home/lbijn/circle/include/circle/exceptionstub.h \
 /home/lbijn/circle/include/circle/sysconfig.h \
 /home/lbijn/circle/include/circle/memorymap.h \
 /home/lbijn/circle/include/circle/spinlock.h \
 /home/lbijn/circle/include/circle/synchronize.h \
 /home/lbijn/circle/include/circle/time.h
