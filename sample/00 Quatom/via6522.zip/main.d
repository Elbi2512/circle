main.o main.d: main.cpp kernel.h \
 /home/lbijn/circle/include/circle/types.h \
 /home/lbijn/circle/include/assert.h \
 /home/lbijn/circle/include/circle/macros.h \
 /home/lbijn/circle/include/circle/multicore.h \
 /home/lbijn/circle/include/circle/sysconfig.h \
 /home/lbijn/circle/include/circle/memorymap.h \
 /home/lbijn/circle/include/circle/memory.h \
 /home/lbijn/circle/include/circle/pagetable.h \
 /home/lbijn/circle/include/circle/heapallocator.h \
 /home/lbijn/circle/include/circle/spinlock.h \
 /home/lbijn/circle/include/circle/synchronize.h \
 /home/lbijn/circle/include/circle/pageallocator.h \
 /home/lbijn/circle/include/circle/actled.h \
 /home/lbijn/circle/include/circle/gpiopin.h \
 /home/lbijn/circle/include/circle/virtualgpiopin.h \
 /home/lbijn/circle/include/circle/koptions.h \
 /home/lbijn/circle/include/circle/bcmpropertytags.h \
 /home/lbijn/circle/include/circle/bcmmailbox.h \
 /home/lbijn/circle/include/circle/bcm2835.h \
 /home/lbijn/circle/include/circle/cputhrottle.h \
 /home/lbijn/circle/include/circle/devicenameservice.h \
 /home/lbijn/circle/include/circle/device.h \
 /home/lbijn/circle/include/circle/ptrlist.h \
 /home/lbijn/circle/include/circle/string.h \
 /home/lbijn/circle/include/circle/stdarg.h \
 /home/lbijn/circle/include/circle/serial.h \
 /home/lbijn/circle/include/circle/interrupt.h \
 /home/lbijn/circle/include/circle/bcm2835int.h \
 /home/lbijn/circle/include/circle/exceptionstub.h \
 /home/lbijn/circle/include/circle/timer.h \
 /home/lbijn/circle/include/circle/logger.h \
 /home/lbijn/circle/include/circle/time.h \
 /home/lbijn/circle/include/circle/usb/usbhcidevice.h \
 /home/lbijn/circle/include/circle/usb/dwhcidevice.h \
 /home/lbijn/circle/include/circle/usb/usbhostcontroller.h \
 /home/lbijn/circle/include/circle/usb/usbcontroller.h \
 /home/lbijn/circle/include/circle/usb/usb.h \
 /home/lbijn/circle/include/circle/usb/usbaudio.h \
 /home/lbijn/circle/include/circle/usb/usbendpoint.h \
 /home/lbijn/circle/include/circle/usb/usbdevice.h \
 /home/lbijn/circle/include/circle/usb/usbconfigparser.h \
 /home/lbijn/circle/include/circle/usb/usbfunction.h \
 /home/lbijn/circle/include/circle/usb/usbhub.h \
 /home/lbijn/circle/include/circle/numberpool.h \
 /home/lbijn/circle/include/circle/usb/xhciendpoint.h \
 /home/lbijn/circle/include/circle/usb/xhcimmiospace.h \
 /home/lbijn/circle/include/circle/usb/xhciring.h \
 /home/lbijn/circle/include/circle/usb/xhci.h \
 /home/lbijn/circle/include/circle/usb/xhciconfig.h \
 /home/lbijn/circle/include/circle/bcmpciehostbridge.h \
 /home/lbijn/circle/include/circle/machineinfo.h \
 /home/lbijn/circle/include/circle/devicetreeblob.h \
 /home/lbijn/circle/include/circle/usb/usbrequest.h \
 /home/lbijn/circle/include/circle/classallocator.h \
 /home/lbijn/circle/include/circle/usb/dwhcirootport.h \
 /home/lbijn/circle/include/circle/usb/usbhcirootport.h \
 /home/lbijn/circle/include/circle/usb/dwhcixferstagedata.h \
 /home/lbijn/circle/include/circle/usb/dwhciframescheduler.h \
 /home/lbijn/circle/include/circle/usb/dwhcixactqueue.h \
 /home/lbijn/circle/include/circle/ptrlistfiq.h \
 /home/lbijn/circle/include/circle/usb/dwhcicompletionqueue.h \
 /home/lbijn/circle/include/circle/usb/dwhciregister.h \
 /home/lbijn/circle/include/circle/usb/dwhci.h \
 /home/lbijn/circle/include/circle/mphi.h \
 /home/lbijn/circle/include/circle/usb/usbkeyboard.h \
 /home/lbijn/circle/include/circle/usb/usbhiddevice.h \
 /home/lbijn/circle/include/circle/input/keyboardbehaviour.h \
 /home/lbijn/circle/include/circle/input/keymap.h \
 /home/lbijn/circle/include/circle/usb/usbhid.h \
 /home/lbijn/circle/include/circle/bcmframebuffer.h \
 /home/lbijn/circle/include/circle/display.h \
 /home/lbijn/circle/include/circle/dmachannel.h \
 /home/lbijn/circle/include/circle/dmacommon.h \
 /home/lbijn/circle/addon/SDCard/emmc.h \
 /home/lbijn/circle/include/circle/fs/partitionmanager.h \
 /home/lbijn/circle/include/circle/fs/partition.h \
 /home/lbijn/circle/addon/SDCard/sdhost.h \
 /home/lbijn/circle/addon/SDCard/mmchost.h \
 /home/lbijn/circle/addon/SDCard/mmc.h \
 /home/lbijn/circle/include/circle/memio.h \
 /home/lbijn/circle/include/circle/fs/fat/fatfs.h \
 /home/lbijn/circle/include/circle/fs/fsdef.h \
 /home/lbijn/circle/include/circle/fs/fat/fatfsdef.h \
 /home/lbijn/circle/include/circle/fs/fat/fatcache.h \
 /home/lbijn/circle/include/circle/genericlock.h \
 /home/lbijn/circle/include/circle/fs/fat/fatinfo.h \
 /home/lbijn/circle/include/circle/fs/fat/fat.h \
 /home/lbijn/circle/include/circle/fs/fat/fatdir.h \
 /home/lbijn/circle/addon/fatfs/ff.h \
 /home/lbijn/circle/addon/fatfs/ffconf.h \
 /usr/lib/gcc/arm-none-eabi/14.2.1/include/stdint.h \
 /home/lbijn/circle/include/circle/util.h atomemulator.h \
 /usr/include/newlib/stdlib.h /usr/include/newlib/machine/ieeefp.h \
 /usr/include/newlib/_ansi.h /usr/include/newlib/newlib.h \
 /usr/include/newlib/_newlib_version.h /usr/include/newlib/sys/config.h \
 /usr/include/newlib/sys/features.h \
 /usr/lib/gcc/arm-none-eabi/14.2.1/include/stddef.h \
 /usr/include/newlib/sys/reent.h /usr/include/newlib/_ansi.h \
 /usr/include/newlib/sys/cdefs.h \
 /usr/include/newlib/machine/_default_types.h \
 /usr/include/newlib/sys/_types.h /usr/include/newlib/machine/_types.h \
 /usr/include/newlib/sys/lock.h /usr/include/newlib/machine/stdlib.h \
 pia8255.h /home/lbijn/circle/include/circle/string.h via6522.h AtomMC.h \
 /home/lbijn/circle/addon/fatfs/ff.h AtomVideo.h debugger.h textconsole.h \
 /home/lbijn/circle/include/circle/stdarg.h \
 /home/lbijn/circle/include/circle/startup.h
