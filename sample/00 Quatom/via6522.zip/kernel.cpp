
#include "kernel.h"
#include <circle/fs/fat/fatfs.h>
#include <circle/fs/fat/fatdir.h>
#include <circle/util.h>
#include <circle/memory.h>
#include <circle/logger.h>
#define DBG(fmt, ...) \
   CLogger::Get()->Write("DBG", LogDebug, fmt, ##__VA_ARGS__)


static const char FromKernel[] = "kernel";

static volatile bool g_bFullscreenMode = false;
static volatile unsigned g_FullscreenCore = 0;

static unsigned g_SkipCounter[4] = {0, 0, 0, 0};

volatile unsigned CKernel::m_nActiveCore = 0;
static const u64 FRAME_TIME_US = 20000;
static const u64 MAX_CATCHUP_US = FRAME_TIME_US * 5;
static volatile unsigned g_nCoreLoad[4] = {0, 0, 0, 0}; // 0 - 100%

CKernel *CKernel::s_pThis = nullptr;
CWelcomeAnimation g_WelcomeAnim;

void RenderCoreQuadrant(CBcmFrameBuffer &frameBuffer, unsigned nCoreId, const u8 *pLocalVRAM);
void DrawFocusBorders(CBcmFrameBuffer &frameBuffer, unsigned nActiveCore);
void RenderSingleCoreFullscreen(CBcmFrameBuffer &frameBuffer, unsigned nCoreId, const u8 *pLocalVRAM);

CKernel::CKernel(void)
    : CMultiCoreSupport(CMemorySystem::Get()),
      m_DeviceNameService(),
      m_FrameBuffer(0, 0, 32), // <-- Laat de resolutie dynamisch bepalen door de framebuffer driver
      m_Serial(&m_Interrupt),
      m_Timer(&m_Interrupt),
      m_Logger(m_Options.GetLogLevel(), &m_Timer),
      m_EMMC(&m_Interrupt, &m_Timer, &m_ActLED),
      m_FileSystem(), // leeglaten CFATFileSystem object, wordt later gemount
      m_USBHCI(&m_Interrupt, &m_Timer, TRUE),
      m_pKeyboard(nullptr),
      m_ShutdownMode(ShutdownNone),
      m_bUSBOK(FALSE),
      m_bCoreInitDone(FALSE)

{
  s_pThis = this;
}

CKernel::~CKernel(void)
{
  s_pThis = nullptr;
}

boolean CKernel::Initialize(void)
{
  boolean bOK = TRUE;

  // 1. Hardware, Interrupts & Timers
  if (bOK)
    bOK = m_Interrupt.Initialize();
  if (bOK)
    bOK = m_Timer.Initialize();
  if (bOK)
    bOK = m_Serial.Initialize(115200);
  if (bOK)
    bOK = m_Logger.Initialize(&m_Serial);

  // 2. Beeldscherm & SD-kaart
  if (bOK)
    bOK = m_FrameBuffer.Initialize();
  if (bOK)
    bOK = m_EMMC.Initialize();
  if (bOK)
  {
    // Positie rechts: bijvoorbeeld op x = 1040 (direct rechts van de Atom-vensters op x=1036)
    // en y = 24.
    m_pConsole = new CTextConsole(&m_FrameBuffer, 1040, 24, 0xFFFFFFFF, 0xFF080808); // Groene tekst op donkere achtergrond
    m_pConsole->WriteString("Quatom Multi-Core Monitor Ready.\r\n");
    m_pConsole->WriteString("-----------------------------------------\r\n");
  }
  if (bOK)
  {
    static FATFS fatfs;
    FRESULT res = f_mount(&fatfs, "SD:", 1);
    bOK = (res == FR_OK);
  }
if (bOK)
  {
    m_Logger.Write(FromKernel, LogNotice, "Bezig met laden van AtomMP4.bin...");
    if (!g_WelcomeAnim.Initialize("SD:/AtomMP4.bin"))
    {
      m_Logger.Write(FromKernel, LogError, "Kan AtomMP4.bin niet laden, maar we gaan door...");
    }
    else
    {
      m_Logger.Write(FromKernel, LogNotice, "AtomMP4.bin succesvol geladen!");
    }
  }
  // 3. USB Host Controller WEL OP TIJD INITIALISEREN (vóór emulators/cores)
  if (bOK)
  {
    bOK = m_USBHCI.Initialize();
  }

  // 4. Multi-Core ondersteuning starten
  if (bOK)
  {
    bOK = CMultiCoreSupport::Initialize();
  }

  // 5. Atom Emulator Init voor alle 4 de cores
  if (bOK)
  {
    for (int core = 0; core < 4; core++)
    {
      m_Logger.Write(FromKernel, LogNotice, "--> Starten van AtomEmulator %d", core);
      bOK = m_AtomEmulator[core].Initialize(core);
      // Koppel de hoofdklasse hier aan de emulator!
      m_AtomEmulator[core].SetKernel(this);
    }
  }

  // 6. Pas als ALLES klaar is, de slave-cores loslaten
  if (bOK)
  {
    DrawFocusBorders(s_pThis->m_FrameBuffer, 0);
    m_bCoreInitDone = TRUE;
  }

  return bOK;
}

void DrawVUMeter(CBcmFrameBuffer &fb, int x, int y, int width, int height, unsigned pct)
{
  if (!g_bTrueFullscreen)
  {
    u32 *pBuffer = (u32 *)fb.GetBuffer();
    unsigned pitchWords = fb.GetPitch() / 4;

    if (pct > 100)
      pct = 100;

    int filledWidth = (width * (int)pct) / 100;
    // Kleur bepalen op basis van belasting
    u32 fillColor;

    if (pct < 60)
      fillColor = 0xFF00D000; // Groen (BGRA)
    else if (pct < 85)
      fillColor = 0xFFFFA500; // Oranje
    else
      fillColor = 0xFFFF2020; // Rood

    u32 bgColor = 0xFF202020;     // Donkergrijs
    u32 borderColor = 0xFF808080; // Lichtgrijs kader

    for (int dy = 0; dy < height; dy++)
    {
      int py = y + dy;
      for (int dx = 0; dx < width; dx++)
      {
        int px = x + dx;
        u32 color;
        // Buitenste rand (1 pixel)
        if (dx == 0 || dx == width - 1 || dy == 0 || dy == height - 1)
        {
          color = borderColor;
        }
        // Gevulde actieve balk
        else if (dx <= filledWidth)
        {
          color = fillColor;
        }
        // Lege achtergrond
        else
        {
          color = bgColor;
        }
        pBuffer[py * pitchWords + px] = color;
      }
    }
  }
}

void CKernel::Run(unsigned nCore)
{
  while (!m_bCoreInitDone)
  {
    asm volatile("dmb" ::
                     : "memory");
  }

  unsigned coreIdx = nCore - 1;
  if (coreIdx < 3)
  {
    m_Logger.Write(FromKernel, LogNotice, "Core %d: Acorn Atom Emulator gestart...", nCore);

    u64 nNextFrameTime = m_Timer.GetClockTicks64();
    unsigned long frameCount = 0; 

    while (m_ShutdownMode == ShutdownNone)
    {
      u64 nCurrentTime = m_Timer.GetClockTicks64();

      frameCount++;
      if (frameCount % 300000 == 0) // Pas gelogd na 300k frames (ca. 1x per minuut)
      {
        DBG("Core %d stat: VRAMChanged=%d, Load=%u%%",
            coreIdx,
            m_AtomEmulator[coreIdx].HasVRAMChanged(),
            g_nCoreLoad[coreIdx]);
      }

      if (nCurrentTime > nNextFrameTime + MAX_CATCHUP_US)
        nNextFrameTime = nCurrentTime;

      const u64 tStart = m_Timer.GetClockTicks64();

      // 1. Emulatie‑update
      m_AtomEmulator[coreIdx].Update();

      // 2. VRAM‑status
      const bool bVRAM = m_AtomEmulator[coreIdx].HasVRAMChanged();
      bool bDoRender = false;

      // VRAM veranderd? Altijd renderen, anders pas na 10 frames (was 5) om CPU te sparen
      if (bVRAM)
      {
        bDoRender = true;
      }
      else
      {
        if (++g_SkipCounter[coreIdx] >= 5)
          bDoRender = true;
      }

      if (bDoRender)
      {
        g_SkipCounter[coreIdx] = 0;

        if (g_bFullscreenMode)
        {
          if (g_FullscreenCore == coreIdx)
            RenderSingleCoreFullscreen(m_FrameBuffer, coreIdx, m_AtomEmulator[coreIdx].GetVRAMPointer());
        }
        else
        {
          RenderCoreQuadrant(m_FrameBuffer, coreIdx, m_AtomEmulator[coreIdx].GetVRAMPointer());
        }

        m_AtomEmulator[coreIdx].ResetVRAMChanged();
      }

      const u64 tWork = m_Timer.GetClockTicks64() - tStart;
      unsigned rawLoad = (unsigned)((tWork * 100) / FRAME_TIME_US);
      if (rawLoad > 100)
        rawLoad = 100;
      g_nCoreLoad[coreIdx] = (g_nCoreLoad[coreIdx] * 7 + rawLoad) / 8;

      nNextFrameTime += FRAME_TIME_US;
      while (m_Timer.GetClockTicks64() < nNextFrameTime)
      {
        asm volatile("wfe");
      }
    }
  }
}

TShutdownMode CKernel::Run(void)
{
  m_Logger.Write(FromKernel, LogNotice, "Core 0 Run-loop gestart (USB, I/O Master & Emulator 3)...");

  u64 nNextFrameTime = m_Timer.GetClockTicks64();
  unsigned long frameCountCore0 = 0; 

  while (m_ShutdownMode == ShutdownNone)
  {
    // 1. USB keyboard detectie
    if (m_pKeyboard == nullptr)
    {
      CDevice *pDev = m_DeviceNameService.GetDevice("ukbd1", FALSE);
      if (pDev != nullptr)
      {
        m_pKeyboard = (CUSBKeyboardDevice *)pDev;
        m_pKeyboard->RegisterKeyStatusHandlerRaw(KeyStatusHandlerRaw);
        m_pKeyboard->RegisterRemovedHandler(KeyboardRemovedHandler);
        m_Logger.Write(FromKernel, LogNotice, "SUCCESS: USB Toetsenbord gekoppeld op Core 0!");
        m_bKeyboardReady = TRUE;
      }
    }

    if (m_pKeyboard != nullptr)
    {
      m_pKeyboard->UpdateLEDs();
    }

    u64 nCurrentTime = m_Timer.GetClockTicks64();

    // frameCountCore0++;
    // if (frameCountCore0 % 300000 == 0) // Pas gelogd na 300k frames
    // {
    //   DBG("Core 0 stat: Actieve Core = %u, KeyboardReady = %d", 
    //       m_nActiveCore, m_bKeyboardReady);
    // }

    if (nCurrentTime >= nNextFrameTime)
    {
      if (nCurrentTime > nNextFrameTime + MAX_CATCHUP_US) {
        nNextFrameTime = nCurrentTime;
      }
      const u64 tStart = m_Timer.GetClockTicks64();

      unsigned coreIdx = 3; // core 0 index

      // Emulator 3 (core 0 index 3)
      m_AtomEmulator[coreIdx].Update();
      
      static u64 lastAnimTick = 0;
      u64 now = m_Timer.GetClockTicks64();

      if (now - lastAnimTick >= FRAME_TIME_US) // dit deel voor de draaiende atom op openingsscherm
      {
        lastAnimTick = now;
        g_WelcomeAnim.UpdateAnimation();
      }
      
      const bool bVRAM = m_AtomEmulator[coreIdx].HasVRAMChanged();
      bool bDoRender = false;

      if (bVRAM)
      {
        bDoRender = true;
      }
      else
      {
        if (++g_SkipCounter[coreIdx] >= 5) // Verhoogd naar 10 frames om belasting te drukken
          bDoRender = true;
      }

      if (bDoRender)
      {
        g_SkipCounter[coreIdx] = 0;

        if (g_bFullscreenMode)
        {
          if (g_FullscreenCore == coreIdx)
            RenderSingleCoreFullscreen(m_FrameBuffer, coreIdx, m_AtomEmulator[coreIdx].GetVRAMPointer());
        }
        else
        {
          RenderCoreQuadrant(m_FrameBuffer, coreIdx, m_AtomEmulator[coreIdx].GetVRAMPointer());
        }

        m_AtomEmulator[coreIdx].ResetVRAMChanged();
      }

      const u64 tWork = m_Timer.GetClockTicks64() - tStart;
      unsigned rawLoad = (unsigned)((tWork * 100) / FRAME_TIME_US);
      if (rawLoad > 100)
        rawLoad = 100;
      g_nCoreLoad[coreIdx] = (g_nCoreLoad[coreIdx] * 7 + rawLoad) / 8;

      // VU‑meters elke 250 ms
      static u64 nLastVUTime = 0;
      const u64 nCurrTicks = m_Timer.GetClockTicks64();
      if (nCurrTicks - nLastVUTime >= 250000)
      {
        nLastVUTime = nCurrTicks;
        const u32 fbHeight = m_FrameBuffer.GetHeight();
        for (unsigned c = 0; c < 4; c++)
        {
          const int barX = (2 * 512) + 10;
          const int barY = fbHeight - 10 - ((4 - c) * 15);
          DrawVUMeter(m_FrameBuffer, barX, barY, 325, 10, g_nCoreLoad[c]);
        }
      }

      nNextFrameTime += FRAME_TIME_US;
    }

    asm volatile("nop");
  }

  return m_ShutdownMode;
}

struct TAtomKeyResult
{
  uint8_t atomKey;
  bool bForceShift;
  bool bSuppressShift;
};

static TAtomKeyResult ConvertHIDToAtomKeyCustom(uint8_t hidCode, uint8_t ucModifiers)
{
  TAtomKeyResult res = {0, false, false};
  bool bShift = (ucModifiers & 0x22) != 0; // L-Shift of R-Shift

  // 1. Letters 'A' t/m 'Z' (HID 0x04 t/m 0x1D)
  if (hidCode >= 0x04 && hidCode <= 0x1D)
  {
    res.atomKey = 'A' + (hidCode - 0x04);
    return res;
  }

  // 2. Cursor Pijltjestoetsen
  switch (hidCode)
  {
  case 0x4F:
    res.atomKey = 0x02;
    return res; // Pijl RECHTS
  case 0x50:
    res.atomKey = 0x02;
    res.bForceShift = true;
    return res; // Pijl LINKS  (Right + Shift)
  case 0x51:
    res.atomKey = 0x01;
    res.bForceShift = true;
    return res; // Pijl OMLAAG (Up + Shift)
  case 0x52:
    res.atomKey = 0x01;
    return res; // Pijl OMHOOG
  }

  // 3. Cijferrij '1' t/m '0' (HID 0x1E t/m 0x27)
  if (hidCode >= 0x1E && hidCode <= 0x27)
  {
    if (!bShift)
    {
      res.atomKey = (hidCode == 0x27) ? '0' : ('1' + (hidCode - 0x1E));
      return res;
    }
    else
    {
      switch (hidCode)
      {
      case 0x1F: // Shift + 2 -> Atom '@'
        res.atomKey = '@';
        res.bSuppressShift = true;
        return res;

        //     case 0x23:              // Shift + 6 -> Atom '^'
        //         res.atomKey = 0x03; // ^ toets
        //         res.bSuppressShift = true;
        //         return res;
        //
        //     case 0x24: // Shift + 7 -> Atom '&'
        //         res.atomKey = '7';
        //         res.bSuppressShift = true;
        //         return res;

      case 0x25:                // Shift + 8 -> Atom '*' (Op de Atom matrix is '*' gekoppeld aan Shift + ':')
        res.atomKey = ';';      // Basistoets ';' (Rij 2, Kolom 2)
        res.bForceShift = true; // Met Shift geeft dit '*' op de Atom
        return res;

      case 0x26:           // Shift + 9 -> Atom '('
        res.atomKey = '8'; // Atom '(' zit op de matrix bij '8' met Shift
        res.bForceShift = true;
        return res;

      case 0x27:           // Shift + 0 -> Atom ')'
        res.atomKey = '9'; // Atom ')' zit op de matrix bij '9' met Shift
        res.bForceShift = true;
        return res;

      case 0x39: // USB CAPS LOCK -> Acorn Atom Caps Lock / Matrix teken 0x03
        res.atomKey = 0x03;
        return res;

      default: // Overige shift cijfers (1=!, 3=#, 4=$, 5=%)
        res.atomKey = (hidCode == 0x27) ? '0' : ('1' + (hidCode - 0x1E));
        return res;
      }
    }
  }

  // 4. Speciale symbolen en besturingstoetsen
  switch (hidCode)
  {
  case 0x2B: // USB TAB -> Acorn Atom COPY toets
    res.atomKey = 0x09;
    return res;

  case 0x2E: // USB '=' toets
    if (!bShift)
    {
      res.atomKey = '-';
      res.bForceShift = true; // Shift + '-' = '='
    }
    else
    {
      res.atomKey = ';';
      res.bForceShift = true; // Shift + ';' = '+'
    }
    return res;

  case 0x31: // USB Backslash (ISO / US layout)
  case 0x32: // USB Backslash (Alternatieve scancode / EU layout)
    res.atomKey = '\\';
    return res;

  case 0x34: // USB Single Quote '\''
    res.atomKey = '\'';
    res.bForceShift = true; // Shift + ''' = '"'
    return res;

  case 0x28:
    res.atomKey = '\r';
    return res; // RETURN / ENTER
  case 0x29:
    res.atomKey = 0x1B;
    return res; // ESCAPE
  case 0x2A:
    res.atomKey = 0x08;
    return res; // BACKSPACE / DELETE
  case 0x2C:
    res.atomKey = ' ';
    return res; // SPATIE
  case 0x2D:
    res.atomKey = '-';
    return res;
  case 0x2F:
    res.atomKey = '[';
    return res;
  case 0x30:
    res.atomKey = ']';
    return res;
  case 0x33:
    res.atomKey = ';';
    return res;
  case 0x36:
    res.atomKey = ',';
    return res;
  case 0x37:
    res.atomKey = '.';
    return res;
  case 0x38:
    res.atomKey = '/';
    return res;
  default:
    break;
  }

  return res;
}

void CKernel::KeyStatusHandlerRaw(unsigned char ucModifiers, const unsigned char RawKeys[6])
{
  if (!s_pThis)
    return;

  // HID → Atom mapping per slot (0..5)
  static uint8_t s_lastHID[6] = {0};
  static uint8_t s_lastAtomKey[6] = {0};

  unsigned activeCore = s_pThis->m_nActiveCore;
  unsigned newCore = activeCore;

  // ------------------------------------------------------------
  // 1. Function keys (F1..F12) – core switching, fullscreen, reset
  // ------------------------------------------------------------
  for (int i = 0; i < 6; i++)
  {
    uint8_t hid = RawKeys[i];
    if (!hid)
      continue;

    // F9 → toggle true fullscreen
    if (hid == 0x42)
    {
      g_bTrueFullscreen = !g_bTrueFullscreen;
      CLogger::Get()->Write("kernel", LogNotice,
                            "F9: True Fullscreen = %s", g_bTrueFullscreen ? "AAN" : "UIT");
      continue;
    }

    // F12 → hard reset active core
    if (hid == 0x45)
    {
      s_pThis->m_AtomEmulator[activeCore].Reset();
      CLogger::Get()->Write("kernel", LogNotice,
                            "HARDWARE RESET uitgevoerd voor Core %d via F12!", activeCore);
      continue;
    }

    // F1..F4 → quadrant mode + focus switch
    if (hid >= 0x3A && hid <= 0x3D)
    {
      newCore = hid - 0x3A;

      // --> Voeg dit toe:
      if (g_bFullscreenMode)
      {
        g_bFullscreenMode = false;

        // Forceer een volledige redraw voor alle cores
        for (int i = 0; i < 4; i++)
        {
          g_SkipCounter[i] = 5;
        }

        // Wis het volledige scherm naar zwart om 'rommel' te verwijderen
        if (s_pThis && s_pThis->m_FrameBuffer.GetBuffer())
        {
          memset((void *)s_pThis->m_FrameBuffer.GetBuffer(), 0, s_pThis->m_FrameBuffer.GetSize());
        }
      }
      // <-- einde toevoeging

      g_WelcomeAnim.StopCore(newCore);
      DrawFocusBorders(s_pThis->m_FrameBuffer, newCore);
      continue;
    }

    // F5..F8 → fullscreen mode
    if (hid >= 0x3E && hid <= 0x41)
    {
      g_bFullscreenMode = true;
      g_FullscreenCore = (hid - 0x3E);
      newCore = g_FullscreenCore;
      g_WelcomeAnim.StopCore(newCore);
      continue;
    }

    // Normale type‑toets → stop animatie voor actieve core
    if (hid < 0x3A || hid > 0x45)
    {
      g_WelcomeAnim.StopCore(activeCore);
    }
  }

  // ------------------------------------------------------------
  // 2. Core switch uitvoeren
  // ------------------------------------------------------------
  if (newCore != activeCore)
  {
    s_pThis->m_AtomEmulator[activeCore].ClearKeyboard();
    memset(s_lastHID, 0, sizeof(s_lastHID));
    memset(s_lastAtomKey, 0, sizeof(s_lastAtomKey));

    s_pThis->m_nActiveCore = newCore;

    if (!g_bFullscreenMode)
      DrawFocusBorders(s_pThis->m_FrameBuffer, newCore);

    activeCore = newCore;
  }

  CAtomEmulator &emu = s_pThis->m_AtomEmulator[activeCore];

  // ------------------------------------------------------------
  // 3. Modifier states (Shift, Ctrl, Repeat)
  // ------------------------------------------------------------
  bool physShift = (ucModifiers & 0x22) != 0;
  bool physCtrl = (ucModifiers & 0x11) != 0;
  bool physAlt = (ucModifiers & 0x44) != 0;

  bool forceShift = false;
  bool suppressShift = false;

  for (int i = 0; i < 6; i++)
  {
    if (!RawKeys[i])
      continue;
    TAtomKeyResult r = ConvertHIDToAtomKeyCustom(RawKeys[i], ucModifiers);
    if (r.bForceShift)
      forceShift = true;
    if (r.bSuppressShift)
      suppressShift = true;
  }

  bool effectiveShift = (physShift || forceShift) && !suppressShift;

  emu.SetShiftState(effectiveShift);
  emu.SetCtrlState(physCtrl);
  emu.SetReptState(physAlt);

  // ------------------------------------------------------------
  // 4. KeyDown detectie
  // ------------------------------------------------------------
  for (int i = 0; i < 6; i++)
  {
    uint8_t hid = RawKeys[i];
    if (!hid)
      continue;

    bool alreadyPressed = false;
    for (int j = 0; j < 6; j++)
      if (s_lastHID[j] == hid)
        alreadyPressed = true;

    if (!alreadyPressed)
    {
      TAtomKeyResult r = ConvertHIDToAtomKeyCustom(hid, ucModifiers);
      if (r.atomKey)
      {
        emu.KeyDown(r.atomKey);
        s_lastAtomKey[i] = r.atomKey; // BEWAAR Atom‑key
        s_lastHID[i] = hid;           // BEWAAR HID‑key
      }
    }
  }

  // ------------------------------------------------------------
  // 5. KeyUp detectie (NOOIT opnieuw HID → Atom converteren!)
  // ------------------------------------------------------------
  for (int i = 0; i < 6; i++)
  {
    uint8_t oldHID = s_lastHID[i];
    if (!oldHID)
      continue;

    bool stillPressed = false;
    for (int j = 0; j < 6; j++)
      if (RawKeys[j] == oldHID)
        stillPressed = true;

    if (!stillPressed)
    {
      uint8_t atomKey = s_lastAtomKey[i];
      if (atomKey)
        emu.KeyUp(atomKey);

      s_lastAtomKey[i] = 0;
      s_lastHID[i] = 0;
    }
  }

  // ------------------------------------------------------------
  // 6. Alles los? → matrix volledig resetten
  // ------------------------------------------------------------
  bool allReleased = true;
  for (int i = 0; i < 6; i++)
    if (RawKeys[i] != 0)
      allReleased = false;

  if (allReleased)
  {
    emu.ClearKeyboard();
    memset(s_lastHID, 0, sizeof(s_lastHID));
    memset(s_lastAtomKey, 0, sizeof(s_lastAtomKey));
  }
  // --- VOEG DIT TOE OM DIRECT SCHERMREFRESH TE FORCEERDER NA EEN TOETSAANSLAG ---
  g_SkipCounter[activeCore] = 5; // Zet de skip-teller op max zodat de render-loop meteen triggert
  // ----------------------------------------------------------------------------
  // m_bVRAMChanged = true;
  emu.ForceVRAMChanged();
}

void CKernel::KeyboardRemovedHandler(CDevice *pDevice, void *pContext)
{
  if (s_pThis != nullptr)
  {
    s_pThis->m_Logger.Write(FromKernel, LogNotice, "USB Toetsenbord ontkoppeld.");
    s_pThis->m_pKeyboard = nullptr;
    s_pThis->m_bKeyboardReady = FALSE; // Vlag weer omlaag!
  }
}

void ScanDirectory(const char *pPath, int nDepth = 0)
{
  if (nDepth > 3)
    return; // Niet te diep zoeken

  DIR Directory;
  FILINFO FileInfo;

  FRESULT Result = f_findfirst(&Directory, &FileInfo, pPath, "*");

  while (Result == FR_OK && FileInfo.fname[0])
  {
    if (!(FileInfo.fattrib & (AM_HID | AM_SYS)))
    {
      char indent[32] = {0};
      for (int i = 0; i < nDepth; i++)
      {
        strcat(indent, "  ");
      }

      bool isDir = (FileInfo.fattrib & AM_DIR) != 0;

      if (isDir)
      {
        if (strcmp(FileInfo.fname, ".") != 0 && strcmp(FileInfo.fname, "..") != 0)
        {
          CLogger::Get()->Write("FatFs", LogNotice, "%s[DIR]  /%s", indent, FileInfo.fname);

          char subPath[256];
          strcpy(subPath, pPath);
          strcat(subPath, "/");
          strcat(subPath, FileInfo.fname);

          ScanDirectory(subPath, nDepth + 1);
        }
      }
      else
      {
        // Alleen ROM- en ATM-bestanden tonen om log-saturation te voorkomen
        bool isRelevant = (strstr(FileInfo.fname, ".ROM") != nullptr) || (strstr(FileInfo.fname, ".rom") != nullptr) || (strstr(FileInfo.fname, ".ATM") != nullptr) || (strstr(FileInfo.fname, ".atm") != nullptr);

        if (isRelevant)
        {
          CLogger::Get()->Write("FatFs", LogNotice, "%s[FILE] %-24s (%u bytes)",
                                indent, FileInfo.fname, (unsigned)FileInfo.fsize);
        }
      }
    }

    Result = f_findnext(&Directory, &FileInfo);
  }

  f_closedir(&Directory);
}

void CKernel::ListDirectory(void)
{
  m_Logger.Write(FromKernel, LogNotice, "--- Inhoud van SD-kaart via FatFs ---");
  ScanDirectory("SD:");
}

// Palet op 16-byte grens uitgelijnd
static const u32 Palette8[9] __attribute__((aligned(16))) = {
    0xFF000000, // 0: Zwart
    0xFF00FF00, // 1: Groen
    0xFFFFFF00, // 2: Geel
    0xFF0000FF, // 3: Blauw
    0xFFFF0000, // 4: Rood
    0xFFFFFFFF, // 5: Wit
    0xFF00FFFF, // 6: Cyaan
    0xFFFF00FF, // 7: Magenta
    0xFF101010  // 8: Iets minder zwart
};
static const u32 Palette9[9] __attribute__((aligned(16))) = {
    0xFF101010, // 8: Iets minder zwart
    0xFF00F700, // 1: Groen
    0xFFFFF700, // 2: Geel
    0xFF0000FF, // 3: Blauw
    0xFFFF0000, // 4: Rood
    0xFFFEFEFE, // 5: Wit
    0xFF00F7F7, // 6: Cyaan
    0xFFF700F7, // 7: Magenta
    0xFF101010  // 8: Iets minder zwart
};
/*
void RenderCoreQuadrant(CBcmFrameBuffer &frameBuffer, unsigned nCoreId, const u8 *pLocalVRAM)
{
  if (!pLocalVRAM)
    return;

  u32 *pFB = reinterpret_cast<u32 *>(frameBuffer.GetBuffer());
  if (!pFB)
    return;

  const u32 pitch = frameBuffer.GetPitch() / sizeof(u32);

  constexpr int SRC_W = 256;
  constexpr int SRC_H = 192;

  // Window‑posities (zoals bij jou, maar centraal gedefinieerd)
  const u32 startX = (nCoreId & 1) ? 517 : 4;
  const u32 startY = (nCoreId & 2) ? 387 : 0;

  // 1. Welkomst‑animatie per core
  if (g_WelcomeAnim.IsPlaying(nCoreId))
  {
    g_WelcomeAnim.DrawCurrentFrameCentered(pFB, pitch, startX, startY, nCoreId);
    return; // Nooit animatie updaten hier!
  }

  // 2. Normale Atom‑video met 2x scaling + optionele “minder zwart” voor core 1 & 2
  for (int y = 0; y < SRC_H; y++)
  {
    const int y_prev = (y > 0) ? y - 1 : y;
    const int y_next = (y < SRC_H - 1) ? y + 1 : y;

    const u8 *pSrcPrev = &pLocalVRAM[y_prev * SRC_W];
    const u8 *pSrcCurr = &pLocalVRAM[y * SRC_W];
    const u8 *pSrcNext = &pLocalVRAM[y_next * SRC_W];

    u32 *pDstRow1 = pFB + ((startY + (2 * y)) * pitch) + startX;
    u32 *pDstRow2 = pFB + ((startY + (2 * y + 1)) * pitch) + startX;

    for (int x = 0; x < SRC_W; x++)
    {
      const int x_prev = (x > 0) ? x - 1 : x;
      const int x_next = (x < SRC_W - 1) ? x + 1 : x;

      const u32 P = CAtomVideo::GetColorARGB(pSrcCurr[x]);
      const u32 A = CAtomVideo::GetColorARGB(pSrcPrev[x]);      // boven
      const u32 C = CAtomVideo::GetColorARGB(pSrcCurr[x_prev]); // links
      const u32 B = CAtomVideo::GetColorARGB(pSrcCurr[x_next]); // rechts
      const u32 D = CAtomVideo::GetColorARGB(pSrcNext[x]);      // onder

      u32 e0 = (C == A && C != D && A != B) ? A : P;
      u32 e1 = (A == B && A != C && B != D) ? B : P;
      u32 e2 = (D == C && D != B && C != A) ? C : P;
      u32 e3 = (B == D && B != A && D != C) ? D : P;

      // “Minder zwart” voor core 1 & 2
      // if (nCoreId == 1 || nCoreId == 2)
      // {
      //   if (e0 == Palette8[0])
      //     e0 = Palette8[8];
      //   if (e1 == Palette8[0])
      //     e1 = Palette8[8];
      //   if (e2 == Palette8[0])
      //     e2 = Palette8[8];
      //   if (e3 == Palette8[0])
      //     e3 = Palette8[8];
      // }
      // else {
      //      if (e0 == Palette9[0])
      //     e0 = Palette9[8];
      //   if (e1 == Palette9[0])
      //     e1 = Palette9[8];
      //   if (e2 == Palette8[0])
      //     e2 = Palette9[8];
      //   if (e3 == Palette8[0])
      //     e3 = Palette9[8];     
      // } 

      pDstRow1[2 * x] = e0;
      pDstRow1[2 * x + 1] = e1;
      pDstRow2[2 * x] = e2;
      pDstRow2[2 * x + 1] = e3;
    }
  }
}

void DrawFocusBorders(CBcmFrameBuffer &frameBuffer, unsigned nActiveCore)
{
  u32 *pFB = reinterpret_cast<u32 *>(frameBuffer.GetBuffer());
  if (pFB == nullptr)
  {
    return;
  }

  u32 pitch = frameBuffer.GetPitch() / sizeof(u32);
  u32 nFbWidth = frameBuffer.GetWidth();
  u32 nFbHeight = frameBuffer.GetHeight();

  const u32 nBorderThickness = 1;        // Dikte van de verticale randen is 1 pixel
  const u32 COLOR_ACTIVE = 0xFFFF0000;   // Rood (ARGB)
  const u32 COLOR_INACTIVE = 0xFF404040; // Donkergrijs / Inactief

  // 2x zo grote afmetingen van het window
  constexpr int WIN_W = 512;
  constexpr int WIN_H = 384;

  auto drawSingleBorder = [&](unsigned core, u32 borderColor)
  {
    const int winX = (core & 1) ? 517 : 4; // Rechter kolommen 3 pixels naar links
    const int winY = (core & 2) ? 383 : 0; // Onderste rij 1 pixel hoger (387)

    const int xMin = winX - (int)nBorderThickness;
    const int xMax = winX + WIN_W + (int)nBorderThickness - 1;
    const int yMin = winY;
    const int yMax = winY + WIN_H - 1;

    for (int y = yMin; y <= yMax; y++)
    {
      if (y < 0 || y >= (int)nFbHeight)
        continue;

      u32 *pRow = pFB + (y * pitch);

      for (int x = xMin; x <= xMax; x++)
      {
        if (x < 0 || x >= (int)nFbWidth)
          continue;

        // Alleen de linker- en rechterranden tekenen (horizontale randen vervallen)
        bool isLeftOrRight = (x < winX) || (x >= winX + WIN_W);
        if (isLeftOrRight)
        {
          pRow[x] = borderColor;
        }
      }
    }
  };

  // 1. Teken eerst de inactieve cores
  for (unsigned core = 0; core < 4; core++)
  {
    if (core != nActiveCore)
    {
      drawSingleBorder(core, COLOR_INACTIVE);
    }
  }

  // 2. Teken als allerlaatste de actieve core (rood)
  if (nActiveCore < 4)
  {
    drawSingleBorder(nActiveCore, COLOR_ACTIVE);
  }
}

void RenderSingleCoreFullscreen(CBcmFrameBuffer &frameBuffer, unsigned nCoreId, const u8 *pLocalVRAM)
{
  if (pLocalVRAM == nullptr)
    return;

  u32 *pFB = (u32 *)frameBuffer.GetBuffer();
  if (pFB == nullptr)
    return;

  u32 pitch = frameBuffer.GetPitch() / sizeof(u32);
  u32 fbWidth = frameBuffer.GetWidth();
  u32 fbHeight = frameBuffer.GetHeight();

  constexpr int SRC_W = 256;
  constexpr int SRC_H = 192;
  const int Scale = 4; // 4x schaling -> 1024 x 768 pixels

  int scaledWidth = SRC_W * Scale;  // 1024
  int scaledHeight = SRC_H * Scale; // 768

  u32 startX = 0;
  u32 startY = 0;

  // Als True Fullscreen (F9) aan staat, centreren we het beeld op de HDMI monitor
  if (g_bTrueFullscreen)
  {
    if (fbWidth > (unsigned)scaledWidth)
      startX = (fbWidth - scaledWidth) / 2;
    if (fbHeight > (unsigned)scaledHeight)
      startY = (fbHeight - scaledHeight) / 2;

    // Wis optioneel de randen rondom het gecentreerde Atom-scherm naar zwart
    // (Handig zodat de oude VU-meters en console volledig verdwijnen)
    static bool s_ClearedBackground = false;
    if (!s_ClearedBackground) // Doe dit eenmalig bij omschakeling of per frame indien gewenst
    {
      for (unsigned y = 0; y < fbHeight; y++)
      {
        for (unsigned x = 0; x < fbWidth; x++)
        {
          if (x < startX || x >= startX + scaledWidth || y < startY || y >= startY + scaledHeight)
          {
            pFB[y * pitch + x] = 0xFF000000; // Zwarte achtergrond
          }
        }
      }
    }
  }

  for (int y = 0; y < SRC_H; y++)
  {
    const u8 *pSrcCurr = &pLocalVRAM[y * SRC_W];

    // Extra variabelen voor Scale2x indien nodig
    int y_prev = (y > 0) ? y - 1 : y;
    int y_next = (y < SRC_H - 1) ? y + 1 : y;

    const u8 *pSrcPrev = &pLocalVRAM[y_prev * SRC_W];
    const u8 *pSrcNext = &pLocalVRAM[y_next * SRC_W];

    u32 *pDstRow0 = pFB + ((startY + (4 * y)) * pitch) + startX;
    u32 *pDstRow1 = pFB + ((startY + (4 * y + 1)) * pitch) + startX;
    u32 *pDstRow2 = pFB + ((startY + (4 * y + 2)) * pitch) + startX;
    u32 *pDstRow3 = pFB + ((startY + (4 * y + 3)) * pitch) + startX;

    for (int x = 0; x < SRC_W; x++)
    {
      u32 e0, e1, e2, e3;

      if (g_bTrueFullscreen)
      {
        // GEEN smooth/Scale2x routine: repliceer de pixel rechtstreeks (harde pixel scaling)
        u32 P = CAtomVideo::GetColorARGB(pSrcCurr[x]);

        // // Pas core-specifieke kleuraanpassing toe indien van toepassing
        // if (nCoreId == 1 || nCoreId == 2)
        // {
        //   for (int i = 0; i < 8; i++)
        //   {
        //     if (P == Palette8[i])
        //       P = Palette9[i];
        //   }
        // } 

        e0 = P;
        e1 = P;
        e2 = P;
        e3 = P;
      }
      else
      {
        // Wel Scale2x / smooth routine als True Fullscreen uit staat
        int x_prev = (x > 0) ? x - 1 : x;
        int x_next = (x < SRC_W - 1) ? x + 1 : x;

        u32 P = CAtomVideo::GetColorARGB(pSrcCurr[x]);
        u32 A = CAtomVideo::GetColorARGB(pSrcPrev[x]);
        u32 C = CAtomVideo::GetColorARGB(pSrcCurr[x_prev]);
        u32 B = CAtomVideo::GetColorARGB(pSrcCurr[x_next]);
        u32 D = CAtomVideo::GetColorARGB(pSrcNext[x]);

        e0 = (C == A && C != D && A != B) ? A : P;
        e1 = (A == B && A != C && B != D) ? B : P;
        e2 = (D == C && D != B && C != A) ? C : P;
        e3 = (B == D && B != A && D != C) ? D : P;

       // if (nCoreId == 1 || nCoreId == 2)
      //   {
      //     if (e0 == Palette8[0])
      //       e0 = Palette8[8];
      //     if (e1 == Palette8[0])
      //       e1 = Palette8[8];
      //     if (e2 == Palette8[0])
      //       e2 = Palette8[8];
      //     if (e3 == Palette8[0])
      //       e3 = Palette8[8];
      //   } 
      // }

      // Schrijf naar het 4x4 blok in de framebuffer
      pDstRow0[4 * x] = e0;
      pDstRow0[4 * x + 1] = e0;
      pDstRow1[4 * x] = e0;
      pDstRow1[4 * x + 1] = e0;

      pDstRow0[4 * x + 2] = e1;
      pDstRow0[4 * x + 3] = e1;
      pDstRow1[4 * x + 2] = e1;
      pDstRow1[4 * x + 3] = e1;

      pDstRow2[4 * x] = e2;
      pDstRow2[4 * x + 1] = e2;
      pDstRow3[4 * x] = e2;
      pDstRow3[4 * x + 1] = e2;

      pDstRow2[4 * x + 2] = e3;
      pDstRow2[4 * x + 3] = e3;
      pDstRow3[4 * x + 2] = e3;
      pDstRow3[4 * x + 3] = e3;
    }
  }
}
*/

/*
void RenderSingleCoreFullscreen(CBcmFrameBuffer &frameBuffer, unsigned nCoreId, const u8 *pLocalVRAM) {
  if (!pLocalVRAM)
    return;

  u32 *pFB = reinterpret_cast<u32 *>(frameBuffer.GetBuffer());
  if (!pFB)
    return;

  const u32 pitch = frameBuffer.GetPitch() / sizeof(u32);
  const u32 fbW = frameBuffer.GetWidth();
  const u32 fbH = frameBuffer.GetHeight();

  constexpr int SRC_W = 256;
  constexpr int SRC_H = 192;
  constexpr int SCALE = 4;  // 4x fullscreen

  const int dstW = SRC_W * SCALE;
  const int dstH = SRC_H * SCALE;

  const int startX = (fbW > (u32)dstW) ? (int)((fbW - dstW) / 2) : 0;
  const int startY = (fbH > (u32)dstH) ? (int)((fbH - dstH) / 2) : 0;

  for (int y = 0; y < SRC_H; y++) {
    const int y_prev = (y > 0) ? y - 1 : y;
    const int y_next = (y < SRC_H - 1) ? y + 1 : y;

    const u8 *pSrcPrev = &pLocalVRAM[y_prev * SRC_W];
    const u8 *pSrcCurr = &pLocalVRAM[y * SRC_W];
    const u8 *pSrcNext = &pLocalVRAM[y_next * SRC_W];

    for (int x = 0; x < SRC_W; x++) {
      const int x_prev = (x > 0) ? x - 1 : x;
      const int x_next = (x < SRC_W - 1) ? x + 1 : x;

      const u32 P = CAtomVideo::GetColorARGB(pSrcCurr[x]);
      const u32 A = CAtomVideo::GetColorARGB(pSrcPrev[x]);
      const u32 C = CAtomVideo::GetColorARGB(pSrcCurr[x_prev]);
      const u32 B = CAtomVideo::GetColorARGB(pSrcCurr[x_next]);
      const u32 D = CAtomVideo::GetColorARGB(pSrcNext[x]);

      u32 e0 = (C == A && C != D && A != B) ? A : P;
      u32 e1 = (A == B && A != C && B != D) ? B : P;
      u32 e2 = (D == C && D != B && C != A) ? C : P;
      u32 e3 = (B == D && B != A && D != C) ? D : P;

      // 4x4 block vullen
      const int baseX = startX + x * SCALE;
      const int baseY = startY + y * SCALE;

      for (int dy = 0; dy < SCALE; dy++) {
        u32 *pRow = pFB + (baseY + dy) * pitch + baseX;
        for (int dx = 0; dx < SCALE; dx++) {
          // simpele verdeling: boven‑links e0, boven‑rechts e1, onder‑links e2, onder‑rechts e3
          const bool top = (dy < SCALE / 2);
          const bool left = (dx < SCALE / 2);
          const u32 color = top ? (left ? e0 : e1) : (left ? e2 : e3);
          pRow[dx] = color;
        }
      }
    }
  }
}
*/


////////////////////////
void RenderCoreQuadrant(CBcmFrameBuffer &frameBuffer, unsigned nCoreId, const u8 *pLocalVRAM)
{
if (!pLocalVRAM)
{
    DBG("Core %d: VRAM pointer NULL!", nCoreId);
    return;
}

    u32 *pFB = reinterpret_cast<u32 *>(frameBuffer.GetBuffer());
    if (!pFB)
        return;

    const u32 pitch = frameBuffer.GetPitch() / sizeof(u32);

    constexpr int SRC_W = 256;
    constexpr int SRC_H = 192;

    // NIEUW: veilige quadrant-posities
    const u32 startX = (nCoreId & 1) ? 512 : 0;
    const u32 startY = (nCoreId & 2) ? 384 : 0;
if (startX + 512 > frameBuffer.GetWidth())
{
    DBG("OOB core %d: startX=%u fbWidth=%u", 
        nCoreId, startX, frameBuffer.GetWidth());
}

if (startY + 384 > frameBuffer.GetHeight())
{
    DBG("OOB core %d: startY=%u fbHeight=%u", 
        nCoreId, startY, frameBuffer.GetHeight());
}

    // 1. Welkomstanimatie
    if (g_WelcomeAnim.IsPlaying(nCoreId))
    {
        g_WelcomeAnim.DrawCurrentFrameCentered(pFB, pitch, startX, startY, nCoreId);

        // BELANGRIJK: VRAMChanged resetten om freeze te voorkomen
        CKernel::Get()->GetEmulator(nCoreId)->ResetVRAMChanged();
        return;
    }

    // 2. Normale Atom-video met Scale2x
    for (int y = 0; y < SRC_H; y++)
    {
        const int y_prev = (y > 0) ? y - 1 : y;
        const int y_next = (y < SRC_H - 1) ? y + 1 : y;

        const u8 *pSrcPrev = &pLocalVRAM[y_prev * SRC_W];
        const u8 *pSrcCurr = &pLocalVRAM[y * SRC_W];
        const u8 *pSrcNext = &pLocalVRAM[y_next * SRC_W];

        u32 *pDstRow1 = pFB + ((startY + (2 * y)) * pitch) + startX;
        u32 *pDstRow2 = pFB + ((startY + (2 * y + 1)) * pitch) + startX;

        for (int x = 0; x < SRC_W; x++)
        {
            const int x_prev = (x > 0) ? x - 1 : x;
            const int x_next = (x < SRC_W - 1) ? x + 1 : x;

            const u32 P = CAtomVideo::GetColorARGB(pSrcCurr[x]);
            const u32 A = CAtomVideo::GetColorARGB(pSrcPrev[x]);
            const u32 C = CAtomVideo::GetColorARGB(pSrcCurr[x_prev]);
            const u32 B = CAtomVideo::GetColorARGB(pSrcCurr[x_next]);
            const u32 D = CAtomVideo::GetColorARGB(pSrcNext[x]);

            u32 e0 = (C == A && C != D && A != B) ? A : P;
            u32 e1 = (A == B && A != C && B != D) ? B : P;
            u32 e2 = (D == C && D != B && C != A) ? C : P;
            u32 e3 = (B == D && B != A && D != C) ? D : P;

            // Minder zwart voor core 1 & 2
            if (nCoreId == 1 || nCoreId == 2)
            {
                if (e0 == Palette8[0]) e0 = Palette8[8];
                if (e1 == Palette8[0]) e1 = Palette8[8];
                if (e2 == Palette8[0]) e2 = Palette8[8];
                if (e3 == Palette8[0]) e3 = Palette8[8];
            }

            pDstRow1[2 * x]     = e0;
            pDstRow1[2 * x + 1] = e1;
            pDstRow2[2 * x]     = e2;
            pDstRow2[2 * x + 1] = e3;
        }
    }
}
void DrawFocusBorders(CBcmFrameBuffer &frameBuffer, unsigned nActiveCore)
{
    u32 *pFB = reinterpret_cast<u32 *>(frameBuffer.GetBuffer());
    if (!pFB)
        return;

    const u32 pitch = frameBuffer.GetPitch() / sizeof(u32);
    const u32 fbWidth = frameBuffer.GetWidth();
    const u32 fbHeight = frameBuffer.GetHeight();

    constexpr int WIN_W = 512;
    constexpr int WIN_H = 384;
    constexpr u32 BORDER = 1;

    const u32 COLOR_ACTIVE   = 0xFFFF0000;
    const u32 COLOR_INACTIVE = 0xFF404040;

    auto drawBorder = [&](unsigned core, u32 color)
    {
        const int winX = (core & 1) ? 512 : 0;
        const int winY = (core & 2) ? 384 : 0;

        const int xMin = winX - BORDER;
        const int xMax = winX + WIN_W + BORDER - 1;
        const int yMin = winY;
        const int yMax = winY + WIN_H - 1;

        for (int y = yMin; y <= yMax; y++)
        {
            if (y < 0 || y >= (int)fbHeight)
                continue;

            u32 *row = pFB + y * pitch;

            for (int x = xMin; x <= xMax; x++)
            {
                if (x < 0 || x >= (int)fbWidth)
                    continue;

                bool isVerticalBorder = (x < winX) || (x >= winX + WIN_W);
                if (isVerticalBorder)
                    row[x] = color;
            }
        }
    };

    for (unsigned core = 0; core < 4; core++)
        if (core != nActiveCore)
            drawBorder(core, COLOR_INACTIVE);

    drawBorder(nActiveCore, COLOR_ACTIVE);
}
void RenderSingleCoreFullscreen(CBcmFrameBuffer &frameBuffer, unsigned nCoreId, const u8 *pLocalVRAM)
{
    if (!pLocalVRAM)
        return;

    u32 *pFB = (u32 *)frameBuffer.GetBuffer();
    if (!pFB)
        return;

    const u32 pitch = frameBuffer.GetPitch() / sizeof(u32);
    const u32 fbWidth = frameBuffer.GetWidth();
    const u32 fbHeight = frameBuffer.GetHeight();

    constexpr int SRC_W = 256;
    constexpr int SRC_H = 192;
    constexpr int SCALE = 4;

    const int scaledW = SRC_W * SCALE;
    const int scaledH = SRC_H * SCALE;

    u32 startX = 0;
    u32 startY = 0;

    if (g_bTrueFullscreen)
    {
        if (fbWidth > scaledW)  startX = (fbWidth - scaledW) / 2;
        if (fbHeight > scaledH) startY = (fbHeight - scaledH) / 2;

        for (unsigned y = 0; y < fbHeight; y++)
            for (unsigned x = 0; x < fbWidth; x++)
                if (x < startX || x >= startX + scaledW ||
                    y < startY || y >= startY + scaledH)
                    pFB[y * pitch + x] = 0xFF000000;
    }

    for (int y = 0; y < SRC_H; y++)
    {
        const u8 *src = &pLocalVRAM[y * SRC_W];

        u32 *row0 = pFB + (startY + (y * SCALE + 0)) * pitch + startX;
        u32 *row1 = pFB + (startY + (y * SCALE + 1)) * pitch + startX;
        u32 *row2 = pFB + (startY + (y * SCALE + 2)) * pitch + startX;
        u32 *row3 = pFB + (startY + (y * SCALE + 3)) * pitch + startX;

        for (int x = 0; x < SRC_W; x++)
        {
            u32 P = CAtomVideo::GetColorARGB(src[x]);

            if (nCoreId == 1 || nCoreId == 2)
            {
                for (int i = 0; i < 8; i++)
                    if (P == Palette8[i])
                        P = Palette9[i];
            }

            row0[x] = P;
            row1[x] = P;
            row2[x] = P;
            row3[x] = P;
        }
    }
}
