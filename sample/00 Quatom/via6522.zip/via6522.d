via6522.o via6522.d: via6522.cpp via6522.h \
 /usr/lib/gcc/arm-none-eabi/14.2.1/include/stdint.h \
 /home/lbijn/circle/include/circle/types.h \
 /home/lbijn/circle/include/assert.h \
 /home/lbijn/circle/include/circle/macros.h \
 /home/lbijn/circle/include/circle/string.h \
 /home/lbijn/circle/include/circle/stdarg.h
