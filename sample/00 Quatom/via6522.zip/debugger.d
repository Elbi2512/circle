debugger.o debugger.d: debugger.cpp debugger.h \
 /usr/lib/gcc/arm-none-eabi/14.2.1/include/stdint.h \
 /usr/lib/gcc/arm-none-eabi/14.2.1/include/stddef.h \
 /home/lbijn/circle/include/circle/types.h \
 /home/lbijn/circle/include/assert.h \
 /home/lbijn/circle/include/circle/macros.h atomemulator.h \
 /usr/include/newlib/stdlib.h /usr/include/newlib/machine/ieeefp.h \
 /usr/include/newlib/_ansi.h /usr/include/newlib/newlib.h \
 /usr/include/newlib/_newlib_version.h /usr/include/newlib/sys/config.h \
 /usr/include/newlib/sys/features.h /usr/include/newlib/sys/reent.h \
 /usr/include/newlib/_ansi.h /usr/include/newlib/sys/cdefs.h \
 /usr/include/newlib/machine/_default_types.h \
 /usr/include/newlib/sys/_types.h /usr/include/newlib/machine/_types.h \
 /usr/include/newlib/sys/lock.h /usr/include/newlib/machine/stdlib.h \
 pia8255.h /home/lbijn/circle/include/circle/string.h \
 /home/lbijn/circle/include/circle/stdarg.h via6522.h AtomMC.h \
 /home/lbijn/circle/addon/fatfs/ff.h \
 /home/lbijn/circle/addon/fatfs/ffconf.h \
 /home/lbijn/circle/include/circle/fs/fat/fatfs.h \
 /home/lbijn/circle/include/circle/fs/fsdef.h \
 /home/lbijn/circle/include/circle/fs/fat/fatfsdef.h \
 /home/lbijn/circle/include/circle/fs/fat/fatcache.h \
 /home/lbijn/circle/include/circle/device.h \
 /home/lbijn/circle/include/circle/ptrlist.h \
 /home/lbijn/circle/include/circle/string.h \
 /home/lbijn/circle/include/circle/genericlock.h \
 /home/lbijn/circle/include/circle/sysconfig.h \
 /home/lbijn/circle/include/circle/memorymap.h \
 /home/lbijn/circle/include/circle/spinlock.h \
 /home/lbijn/circle/include/circle/synchronize.h \
 /home/lbijn/circle/include/circle/fs/fat/fatinfo.h \
 /home/lbijn/circle/include/circle/fs/fat/fat.h \
 /home/lbijn/circle/include/circle/fs/fat/fatdir.h AtomVideo.h \
 /home/lbijn/circle/include/circle/util.h textconsole.h \
 /home/lbijn/circle/include/circle/bcmframebuffer.h \
 /home/lbijn/circle/include/circle/display.h \
 /home/lbijn/circle/include/circle/bcmpropertytags.h \
 /home/lbijn/circle/include/circle/bcmmailbox.h \
 /home/lbijn/circle/include/circle/bcm2835.h \
 /home/lbijn/circle/include/circle/dmachannel.h \
 /home/lbijn/circle/include/circle/dmacommon.h \
 /home/lbijn/circle/include/circle/interrupt.h \
 /home/lbijn/circle/include/circle/bcm2835int.h \
 /home/lbijn/circle/include/circle/exceptionstub.h \
 /home/lbijn/circle/include/circle/machineinfo.h \
 /home/lbijn/circle/include/circle/devicetreeblob.h \
 /home/lbijn/circle/include/circle/gpiopin.h \
 /home/lbijn/circle/include/circle/stdarg.h \
 /home/lbijn/circle/include/circle/logger.h \
 /home/lbijn/circle/include/circle/timer.h \
 /home/lbijn/circle/include/circle/time.h
